'use strict';

throw new Error("Don't run `jest` directly. Run `yarn test` instead.");
