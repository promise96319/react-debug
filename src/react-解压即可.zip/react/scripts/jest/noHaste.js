'use strict';

module.exports = {
  getHasteName() {
    // We never want Haste.
    return null;
  },
};
