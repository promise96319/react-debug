'use strict';

module.exports = require('bindings')('perfcounters');
